import multiprocessing

bind = "0.0.0.0:8000"

# Sync workers (default)
workers = multiprocessing.cpu_count() * 2 + 1

# REMOVE threads (important)
# threads = 2   ❌ not needed

worker_class = "sync"

timeout = 30
keepalive = 5

accesslog = "-"
errorlog = "-"
loglevel = "info"